// Paste your Supabase project values here after setup.
window.ISLANDPETS_CONFIG = {
  supabaseUrl: "PASTE_SUPABASE_URL_HERE",
  supabaseAnonKey: "PASTE_SUPABASE_ANON_KEY_HERE"
};
